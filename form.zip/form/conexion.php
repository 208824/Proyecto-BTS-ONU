<?php
$host="localhost";
$usuario="id19899071_captura";
$pass="6mP2B6G<SCEY]gT?";
$nomdb="id19899071_escuela";

$conexion=new mysqli("localhost","id19899071_captura","6mP2B6G<SCEY]gT?","id19899071_escuela");

if ($conexion) {

    echo "Conexion exitosa";
    # code...
}
else {
    echo "No se realizo la conexión a la base de datos";
    # code...
}

?>