<?php
include("conexion.php");

$nombre=$_POST['nombre'];
$apellido=$_POST['apellido'];
$asunto=$_POST['asunto'];
$mensaje=$_POST['mensaje'];


//Insetar datos
$query="INSERT INTO formulario(Nombre, Apellidos, Asunto, Mensaje ) 
VALUES ('$nombre','$apellido','$asunto','$mensaje')";
//verificar si se ejecuto

$resultado=$conexion->query($query);

if($resultado) {
    echo "Datos insertados correctamente";
    # code...
}
else{
    echo "No se insertaron los datos";
}
?>